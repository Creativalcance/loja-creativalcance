


import { NextRequest, NextResponse } from "next/server";
import { assertAdminAccess } from "@/lib/auth/assert-admin";
import { getDefaultStrickerLanguage } from "@/lib/stricker/rest/client";
import { syncRestOptionals } from "@/lib/stricker/rest/sync-optionals";
import { type StrickerLanguage } from "@/lib/stricker/rest/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

const ALLOWED_LANGUAGES: StrickerLanguage[] = [
  "BG",
  "CZ",
  "DE",
  "DK",
  "EN",
  "ES",
  "FI",
  "FR",
  "GR",
  "HR",
  "HU",
  "IT",
  "NL",
  "NO",
  "PL",
  "PT",
  "RO",
  "RS",
  "RU",
  "SE",
  "SK",
  "UA",
];

function isAllowedLanguage(value: string): value is StrickerLanguage {
  return ALLOWED_LANGUAGES.includes(value as StrickerLanguage);
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    await assertAdminAccess();

    const body = (await request.json().catch(() => ({}))) as {
      lang?: unknown;
    };

    const langRaw =
      typeof body.lang === "string" && body.lang.trim().length > 0
        ? body.lang.trim().toUpperCase()
        : getDefaultStrickerLanguage();

    if (!isAllowedLanguage(langRaw)) {
      return NextResponse.json(
        {
          success: false,
          message: "Idioma do fornecedor inválido.",
        },
        { status: 400 },
      );
    }

    const result = await syncRestOptionals({
      lang: langRaw,
    });

    return NextResponse.json({
      success: true,
      message: "Variantes e preços do fornecedor sincronizados com sucesso.",
      ...result,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        message:
          error instanceof Error
            ? error.message
            : "Erro inesperado na sincronização REST de variantes e preços.",
      },
      { status: 500 },
    );
  }
}
